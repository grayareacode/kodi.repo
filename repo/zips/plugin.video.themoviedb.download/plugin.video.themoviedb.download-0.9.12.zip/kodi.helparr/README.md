This Kodi addon connects Kodi with Radarr and Sonarr, allowing media that is missing from your local library to easily be sent to Radarr/Sonarr for download.

## Requirements
- Kodi 19 "Matrix" or newer (tested on Kodi v21 and 22)
- Radarr and/or Sonarr already installed and setup.

## How to Use

https://github.com/user-attachments/assets/cac949bc-ab94-4161-bd57-da6df7c17944

## Step 1: Installation

Install in 60 seconds:

https://github.com/user-attachments/assets/2b53ac61-f945-4013-96ed-e875bcb3eb43

## Step 2: Configuration

https://github.com/user-attachments/assets/4d5675b8-5acc-418f-a94a-54e3496634d0

